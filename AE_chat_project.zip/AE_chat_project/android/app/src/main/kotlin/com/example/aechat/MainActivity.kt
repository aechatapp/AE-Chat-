package com.example.aechat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}